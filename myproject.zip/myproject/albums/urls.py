'''from django.urls import path
from . import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
]'''

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),  
    path('index/', views.index, name='index'),  
    path('add_album/', views.add_album, name='add_album'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('delete/<str:file_name>/', views.delete_album, name='delete_album'),
    path('delete_db/<int:album_id>/', views.delete_album_db, name='delete_album_db'),
    path('search/', views.search_albums, name='search_albums'),
    path('edit/<int:album_id>/', views.edit_album, name='edit_album'),
]