'''import os
import json
import uuid
from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import default_storage
from django.http import HttpResponse
from .forms import AlbumForm, UploadFileForm, ALBUM_SCHEMA
import jsonschema
from django.contrib import messages  


ALBUMS_DIR = os.path.join(settings.MEDIA_ROOT, 'albums')

def ensure_albums_dir():
    if not os.path.exists(ALBUMS_DIR):
        os.makedirs(ALBUMS_DIR)

def index(request):
    ensure_albums_dir()
    albums_data = []
    json_files = [f for f in os.listdir(ALBUMS_DIR) if f.endswith('.json')]
    
    if not json_files:
        message = "На сервере нет файлов с данными альбомов."
    else:
        message = None
        for file_name in json_files:
            file_path = os.path.join(ALBUMS_DIR, file_name)
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    albums_data.append({
                        'file_name': file_name,
                        'data': data
                    })
            except (json.JSONDecodeError, IOError):
                
                continue
    
    return render(request, 'index.html', {
        'albums': albums_data,
        'message': message
    })

def add_album(request):
    if request.method == 'POST':
        form = AlbumForm(request.POST)
        if form.is_valid():
            album_data = form.to_json()
            
            file_name = f"{uuid.uuid4()}.json"
            file_path = os.path.join(ALBUMS_DIR, file_name)
            ensure_albums_dir()
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(album_data, f, ensure_ascii=False, indent=4)
            return redirect('index')
    else:
        form = AlbumForm()
    return render(request, 'add_album.html', {'form': form})


def upload_file(request):
    print(f"Request method: {request.method}")  
    print(f"Request.FILES: {request.FILES}")    
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        print(f"Form is valid: {form.is_valid()}")  
        print(f"Form errors: {form.errors}")       
        if form.is_valid():
            uploaded_file = form.cleaned_data['file']
            print(f"Uploaded file: {uploaded_file}")  
            
            
            if uploaded_file is None:
                messages.error(request, "Файл не выбран или не загружен.")
                return render(request, 'upload.html', {'form': form})
            
            
            max_size = 10 * 1024 * 1024  
            try:
                print(f"File size: {uploaded_file.size}")  
                if uploaded_file.size > max_size:
                    messages.error(request, f"Файл слишком большой. Максимальный размер: {max_size // (1024*1024)} MB.")
                    return render(request, 'upload.html', {'form': form})
            except AttributeError:
                messages.error(request, "Ошибка при проверке размера файла.")
                return render(request, 'upload.html', {'form': form})
            
            try:
                content = uploaded_file.read().decode('utf-8')
                print(f"Content length: {len(content)}")  
                data = json.loads(content)  
                jsonschema.validate(instance=data, schema=ALBUM_SCHEMA) 
                
                ensure_albums_dir()
                file_name = f"{uuid.uuid4()}.json"
                file_path = os.path.join(ALBUMS_DIR, file_name)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=4, ensure_ascii=False)  
                print(f"File saved to: {file_path}")  
                messages.success(request, "Файл успешно загружен и валидирован.")
                return redirect('index')  
            except (json.JSONDecodeError, jsonschema.ValidationError) as e:
                messages.error(request, f"Неверный формат JSON или данные не соответствуют схеме: {e}")
                return render(request, 'upload.html', {'form': form})
            except UnicodeDecodeError:
                messages.error(request, "Файл не является корректным текстовым файлом (UTF-8).")
                return render(request, 'upload.html', {'form': form})
    else:
        form = UploadFileForm()
    return render(request, 'upload.html', {'form': form})


    

def delete_album(request, file_name):
    if request.method == 'POST':
        
        safe_file_name = os.path.basename(file_name)  
        if not safe_file_name.endswith('.json'):
            messages.error(request, "Неверный файл для удаления.")
            return redirect('index')
        
        file_path = os.path.join(ALBUMS_DIR, safe_file_name)
        print(f"Попытка удалить файл: {file_path}")  
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                print(f"Файл {safe_file_name} удалён успешно.")  
                messages.success(request, f"Альбом '{safe_file_name}' успешно удалён.")
            except OSError as e:
                print(f"Ошибка удаления: {e}")  
                messages.error(request, f"Ошибка при удалении файла: {e}")
        else:
            print(f"Файл {safe_file_name} не найден.")  
            messages.warning(request, f"Файл '{safe_file_name}' не найден.")
        return redirect('index')
    else:
        
        return redirect('index')
'''

import os
import json
import uuid
import glob
import jsonschema
from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings
from django.http import JsonResponse
from django.contrib import messages
from .forms import AlbumForm, UploadFileForm, EditAlbumForm, ALBUM_SCHEMA
from .models import Album
from django.conf import settings
from django.db import IntegrityError

ALBUMS_DIR = os.path.join(settings.MEDIA_ROOT, 'albums')

def ensure_albums_dir():
    if not os.path.exists(ALBUMS_DIR):
        os.makedirs(ALBUMS_DIR)

def index(request):
    source = request.GET.get('source', 'db')
    if source == 'db':
        albums = list(Album.objects.all().values())  
    elif source == 'file':
        albums = []
        media_dir = os.path.join(settings.MEDIA_ROOT, 'albums')
        if os.path.exists(media_dir):
            for file_path in glob.glob(os.path.join(media_dir, '*.json')):
                file_name = os.path.basename(file_path)
                if not file_name:  
                    continue
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    data['file_name'] = file_name
                    data['id'] = None  
                    albums.append(data)
                except (json.JSONDecodeError, FileNotFoundError, KeyError):
                    continue  
    else:
        albums = list(Album.objects.all().values())
    
    return render(request, 'index.html', {'albums': albums, 'source': source})


def add_album(request):
    if request.method == 'POST':
        form = AlbumForm(request.POST)
        if form.is_valid():
            title = form.cleaned_data['title']
            artist = form.cleaned_data['artist']
            year = form.cleaned_data['year']
            
            
            tracks_input = form.cleaned_data['tracks']
            if tracks_input is None or tracks_input == '':
                tracks = []
            else:
                
                if isinstance(tracks_input, list):
                    tracks = [track.strip() for track in tracks_input if track.strip()]
                else:
                    tracks_str = str(tracks_input)  
                    tracks = [track.strip() for track in tracks_str.split(',') if track.strip()]
            
            source = form.cleaned_data['source']
            
            if source == 'db':
                
                try:
                    album = Album.objects.create(title=title, artist=artist, year=year, tracks=tracks)
                    messages.success(request, f"Альбом '{title}' успешно добавлен в базу данных!")
                except IntegrityError:
                    messages.error(request, "Альбом с таким названием и исполнителем уже существует в базе данных!")
                    return redirect('add_album')
            else:  
                
                data = {
                    'title': title,
                    'artist': artist,
                    'year': year,
                    'tracks': tracks
                }
                
                media_dir = os.path.join(settings.MEDIA_ROOT, 'albums')
                os.makedirs(media_dir, exist_ok=True)
                existing_files = [f for f in os.listdir(media_dir) if f.startswith('album_') and f.endswith('.json')]
                next_id = len(existing_files) + 1
                file_name = f'album_{next_id}.json'
                file_path = os.path.join(media_dir, file_name)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=4)
                
                messages.success(request, f"Альбом '{title}' успешно сохранён в файл {file_name}!")
            
            return redirect('index')
    else:
        form = AlbumForm()
    
    return render(request, 'add_album.html', {'form': form})
def upload_file(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = form.cleaned_data['file']
            max_size = 10 * 1024 * 1024
            if uploaded_file.size > max_size:
                messages.error(request, f"Файл слишком большой. Максимальный размер: {max_size // (1024*1024)} MB.")
                return render(request, 'upload.html', {'form': form})
            try:
                content = uploaded_file.read().decode('utf-8')
                data = json.loads(content)
                jsonschema.validate(instance=data, schema=ALBUM_SCHEMA)
                ensure_albums_dir()
                file_name = f"{uuid.uuid4()}.json"
                file_path = os.path.join(ALBUMS_DIR, file_name)
                file_name = f"{uuid.uuid4()}.json"
                file_path = os.path.join(ALBUMS_DIR, file_name)
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=4, ensure_ascii=False)
                messages.success(request, "Файл успешно загружен и валидирован.")
                return redirect('index')
            except (json.JSONDecodeError, jsonschema.ValidationError) as e:
                messages.error(request, f"Неверный формат JSON или данные не соответствуют схеме: {e}")
                return render(request, 'upload.html', {'form': form})
            except UnicodeDecodeError:
                messages.error(request, "Файл не является корректным текстовым файлом (UTF-8).")
                return render(request, 'upload.html', {'form': form})
    else:
        form = UploadFileForm()
    return render(request, 'upload.html', {'form': form})

def delete_album(request, file_name):
    if request.method == 'POST':
        safe_file_name = os.path.basename(file_name)
        if not safe_file_name.endswith('.json'):
            messages.error(request, "Неверный файл для удаления.")
            return redirect('index')
        file_path = os.path.join(ALBUMS_DIR, safe_file_name)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                messages.success(request, f"Файл '{safe_file_name}' успешно удалён.")
            except OSError as e:
                messages.error(request, f"Ошибка при удалении файла: {e}")
        else:
            messages.warning(request, f"Файл '{safe_file_name}' не найден.")
    return redirect('index')

def search_albums(request):
    query = request.GET.get('q', '')
    if query:
        albums = Album.objects.filter(title__icontains=query) | Album.objects.filter(artist__icontains=query)
    else:
        albums = Album.objects.all()
    data = [{'id': album.id, 'title': album.title, 'artist': album.artist, 'year': album.year, 'tracks': album.tracks} for album in albums]
    return JsonResponse({'albums': data})

def edit_album(request, album_id):
    album = get_object_or_404(Album, id=album_id)
    if request.method == 'POST':
       
        album.title = request.POST.get('title')
        album.artist = request.POST.get('artist')
        album.year = int(request.POST.get('year'))
        tracks_str = request.POST.get('tracks')
        album.tracks = [track.strip() for track in tracks_str.split(',')]  
        album.save()
        return redirect('index')  
    return render(request, 'edit_album.html', {'album': album})
def delete_album_db(request, album_id):
    if request.method == 'POST':  
        album = get_object_or_404(Album, id=album_id)
        album.delete()
        messages.success(request, f"Альбом '{album.title}' удалён из базы данных!")
    return redirect('index')