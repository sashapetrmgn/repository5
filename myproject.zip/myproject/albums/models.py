from django.db import models

class Album(models.Model):
    title = models.CharField(max_length=200)
    artist = models.CharField(max_length=200)
    year = models.IntegerField()
    tracks = models.JSONField()  # Хранит список треков как JSON

    class Meta:
        unique_together = ('title', 'artist')  # Проверка на дубликаты по title и artist
        ordering = ['title']

    def __str__(self):
        return f"{self.title} by {self.artist}"

    def to_dict(self):
        return {
            'title': self.title,
            'artist': self.artist,
            'year': self.year,
            'tracks': self.tracks,
        }