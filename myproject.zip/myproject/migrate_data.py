import os
import django
from django.conf import settings

# Настройка Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'albums_project.settings')
django.setup()

from albums.models import Album
import sqlite3

# Подключение к старой SQLite БД
sqlite_conn = sqlite3.connect('db.sqlite3')  # Замените на путь к вашей SQLite БД
cursor = sqlite_conn.cursor()

# Получение данных
cursor.execute("SELECT title, artist, year, tracks FROM albums_album")
albums = cursor.fetchall()

# Перенос в PostgreSQL
for album in albums:
    title, artist, year, tracks = album
    Album.objects.create(title=title, artist=artist, year=year, tracks=tracks)

sqlite_conn.close()
print("Миграция завершена!")